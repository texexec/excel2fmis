### Run ansible
```
git clone --recursive https://github.com/eoli3n/arch-config
cd arch-config/ansible
ansible-playbook install-{zfs,btrfs}.yml -K
```
