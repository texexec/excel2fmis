# Documentation

As you see right now, there is not much. The [main readme](../README.md) file contains all without beeing bloated.

