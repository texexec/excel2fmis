# Help section

## Solved issues

* [Boot not working after install](001_boot_not_working_after_install.md)

## Open issues

